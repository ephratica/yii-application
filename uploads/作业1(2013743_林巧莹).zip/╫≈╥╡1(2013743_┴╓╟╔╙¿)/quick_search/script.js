// 创建点击按钮
var btn = {
    "id":"search",
    "title":"search on Bing",
    "contexts":["selection"]
};
    
// 在background中创建contextMenus并监听点击事件
chrome.contextMenus.create(btn);
// 设置监听
chrome.contextMenus.onClicked.addListener(function(clickData){
    // 如果点击了搜索按钮并且有内容被选中
    if (clickData.menuItemId == 'search' && clickData.selectionText){
        // 要访问的网页是Bing的网址+选中的关键词
        var URL = "https://cn.bing.com/search?q=" + clickData.selectionText;
        var createData = {
            "url":URL
        }
        // 在新窗⼝中查询该关键词
        chrome.windows.create(createData);
    }
});