// ==UserScript==
// @name         寻找丁真爱好者
// @namespace    NightSwan
// @version      0.371
// @description  在b站评论区标注用户动态中是否包含丁真
// @author       ephratica(参考xulaupuz&nightswan的作品)
// @match        https://www.bilibili.com/video/*
// @match        https://t.bilibili.com/*
// @match        https://space.bilibili.com/*
// @match        https://space.bilibili.com/*
// @match        https://www.bilibili.com/read/*
// @icon         https://static.hdslb.com/images/favicon.ico
// @connect      bilibili.com
// @grant        GM_xmlhttpRequest
// @license MIT
// @run-at document-end
// ==/UserScript==

(function () {
    'use strict';
    //const unknown = new Set()

    const dz = new Set()
    const no_dz = new Set()


    //关键词
    const keyword_dz = "丁真"

    //标签内容
    const tag_dz = " 纯真的眼神"


    const blog = 'https://api.bilibili.com/x/polymer/web-dynamic/v1/feed/space?&host_mid='
    const is_new = document.getElementsByClassName('item goback').length != 0 // 检测是不是新版

    //标签颜色
    const tag_dz_Inner = "<b style='color: #946845'>" + tag_dz + "</b>"

    const get_pid = (c) => {
        if (is_new) {
            return c.dataset['userId']
        } else {
            return c.children[0]['href'].replace(/[^\d]/g, "")
        }
    }

    const get_comment_list = () => {
        if (is_new) {
            let lst = new Set()
            for (let c of document.getElementsByClassName('user-name')) {
                lst.add(c)
            }
            for (let c of document.getElementsByClassName('sub-user-name')) {
                lst.add(c)
            }
            return lst
        } else {
            return document.getElementsByClassName('user')
        }
    }


    console.log(is_new)
    console.log("正常加载")


    let jiance = setInterval(() => {
        let commentlist = get_comment_list()
        if (commentlist.length != 0) {
            commentlist.forEach(c => {
                let pid = get_pid(c)
                if (dz.has(pid)) {
                    if (c.textContent.includes(tag_dz) === false) {
                        c.innerHTML += tag_dz_Inner
                    }
                    return
                } else if (no_dz.has(pid)) {
                    // do nothing
                    return
                }
                //unknown.add(pid)
                let blogurl = blog + pid
                GM_xmlhttpRequest({
                    method: "get",
                    url: blogurl,
                    data: '',
                    headers: {
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36'
                    },
                    onload: function (res) {
                        if (res.status === 200) {
                            let st = JSON.stringify(JSON.parse(res.response).data)
                            //unknown.delete(pid)
                            if (st.includes(keyword_dz) || st.includes(keyword_ccj) || st.includes(keyword_gcb)) {
                                c.innerHTML += "<b style='color: #946845' >【 理塘 |  "
                                //添加标签
                                if (st.includes(keyword_dz)) {
                                    c.innerHTML += tag_dz_Inner
                                    dz.add(pid)
                                } else {
                                    no_dz.add(pid)
                                }
                                c.innerHTML += "<b style='color: #946845' >】</b>"
                            }
                        } else {
                            console.log('失败')
                            console.log(res)
                        }
                    },
                });
            });
        }
    }, 4000)
})();