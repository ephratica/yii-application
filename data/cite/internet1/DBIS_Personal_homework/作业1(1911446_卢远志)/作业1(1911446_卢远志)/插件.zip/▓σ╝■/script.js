alert("吃了吗您？");
var arr=["红烧肉","锅包肉","油闷大虾","番茄炒蛋","肉末茄子","火锅","清蒸南瓜"]
var index=parseInt(Math.random()*arr.length)
document.getElementById("su").value=arr[index];
var objectdiv=document.getElementById('s_kw_wrap');
objectdiv.click();