//创建点击按钮
var Button = {
    "id":"youdao",
    "title":"Youdao",
    "contexts":["selection"]
};
//在background中创建contextMenus并监听点击事件
chrome.contextMenus.create(Button);

//设置监听
chrome.contextMenus.onClicked.addListener(function(clickData){
    //判断是否点击了该插件的按钮并且是否一定有内容选中
    if(clickData.menuItemId == 'youdao' && clickData.selectionText){
        //将有道的URL前半部分和要查询的词语进行拼接
        var URL = "https://www.youdao.com/w/eng/" + clickData.selectionText;
        var createData = {
            "url":URL
        }
        //在新窗口中查询该词语
        chrome.windows.create(createData);
    }
});